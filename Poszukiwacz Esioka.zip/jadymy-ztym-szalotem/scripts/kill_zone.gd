extends Area2D

@onready var sound_explosion = $SoundExplosion



func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		sound_explosion.play()
		
	body.felldown()
