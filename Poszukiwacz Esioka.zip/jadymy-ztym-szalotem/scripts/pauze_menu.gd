extends Control


func _ready() -> void:
	$".".visible = false

func resume():
	get_tree().paused = false
	$".".visible = false
	
func pause():
	$".".visible = true
	get_tree().paused = true

func testEsc():
	if Input.is_action_just_pressed("Pause") && !get_tree().paused:
		pause()
	elif Input.is_action_just_pressed("Pause") && get_tree().paused:
		resume()

func _process(delta: float) -> void:
	testEsc()
