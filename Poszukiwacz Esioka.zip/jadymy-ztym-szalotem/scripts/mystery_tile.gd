extends StaticBody2D

@onready var area_2d: Area2D = $Area2D
@onready var animation_player: AnimationPlayer = $AnimationPlayer
@onready var timer: Timer = $Timer
@onready var game_manager: Node = %GameManager

const SPEED = -100

var is_active : bool = false
var timeout : bool= false
var starting_position : int

func _ready() -> void:
	starting_position = position.y

func _physics_process(delta: float) -> void:
	if is_active:
		if not timeout:
			position.y += SPEED * delta
		elif timeout:
			position.y = move_toward(position.y, starting_position, abs(SPEED) * delta)


func coin_up():
	animation_player.play("new_animation")
	game_manager.add_point()

func fruit_spawn():
	animation_player.play("new_animation_2")
	
	var fruit = preload("res://scenes/fruit.tscn").instantiate()
	get_parent().add_child(fruit)
	fruit.global_position = global_position + Vector2(0, -16)
	
	#fruit.get_node("CollisionShape2D").set_deferred("disabled", true)
	
	var tween = create_tween()
	fruit.modulate.a = 0
	#tween.parallel().tween_property(fruit, "position:y", fruit.position.y - 16, 0.5)
	tween.parallel().tween_property(fruit, "modulate:a", 1.0, 0.8)

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "Player" and not timeout:
		is_active = true
		timer.start()
		var rng = round(randf_range(1, 10))
		print(rng)
		
		if rng > 2:
			coin_up()
		elif rng <= 2:
			call_deferred("fruit_spawn")

func _on_timer_timeout() -> void:
	timeout = true
