extends Control

@onready var main_buttons: VBoxContainer = $MainButtons
@onready var ustawienia: Panel = $Ustawienia

func _ready() -> void:
	main_buttons.visible = true
	ustawienia.visible = false

func _on_start_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/level1.tscn")

func _on_ustawienia_pressed() -> void:
	main_buttons.visible = false
	ustawienia.visible = true

func _on_wyjscie_pressed() -> void:
	get_tree().quit()


func _on_back_pressed() -> void:
	_ready()
