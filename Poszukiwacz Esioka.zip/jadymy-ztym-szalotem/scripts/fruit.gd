extends CharacterBody2D

@onready var audio_stream_player_2d: AudioStreamPlayer2D = $AudioStreamPlayer2D
@onready var pickup_box: Area2D = $PickupBox

const SPEED = 15

var direction = 0


func _ready() -> void:
	var rng = round(randf())
	if rng >= 1:
		direction = 1
	elif rng < 1:
		direction = -1

func _physics_process(delta: float) -> void:
	move(delta)
	
	move_and_slide()


func move(delta: float):
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	velocity.x = SPEED * direction

func dead():
	queue_free()

func _on_pickup_box_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		body.health_up()
		pickup_box.set_deferred("monitoring", true)
		audio_stream_player_2d.play()

func _on_audio_stream_player_2d_finished() -> void:
	queue_free()
